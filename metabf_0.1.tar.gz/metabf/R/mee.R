#' @title Maximum evidence estimate
#'
#' @description Compute the maximum evidence estimates of the parameters of the
#'     normal-normal hierarchical model based on a set of observed effect
#'     estimates and standard errors.
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param theta Prior for effect size in case it is a nuisance parameter. Can be
#'     a numeric (a point prior) or a prior density function (a continuous prior
#'     distribution). Defaults to \code{NULL}.
#' @param tau Prior for heterogeneity standard deviation in case it is a
#'     nuisance parameter. Can be a scalar (a point prior) or a prior density
#'     function (a continuous prior distribution). Defaults to \code{NULL}.
#' @param thetaLim Integration and optimization limits for theta. It is only
#'     recommended to change this argument if a prior distribution truncated to
#'     some interval is specified. Defaults to \code{c(-Inf, Inf)}.
#' @param ... Additional arguments passed to \code{stats::integrate}.
#'
#' @return The maximum evidence estimate
#'
#' @author Samuel Pawel
#'
#' @examples
#' yi <- c(0.5, 0.3, 0.1, 0.4)
#' sei <- c(0.05, 0.06, 0.1, 0.03)
#'
#' ## both parameters are in the focus
#' mee(yi = yi, sei = sei)
#'
#' ## common-effect model
#' mee(yi = yi, sei = sei, tau = 0)
#'
#' ## prior on heterogeneity
#' mee(yi = yi, sei = sei, tau = function(x) dnorm(x = x)*2)
#'
#' ## prior on effect size
#' mee(yi = yi, sei = sei, theta = function(x) dnorm(x))
#'
#'
#' @export
mee <- function(yi, sei, theta = NULL, tau = NULL, thetaLim = c(-Inf, Inf),
                ...) {

    ## parameters for initializing the optimization
    vMA <- 1/sum(1/sei^2)
    tMA <- sum(yi/sei^2)*vMA
    Q <- sum((yi - tMA)^2/sei^2)
    tau2DL <- max(c(0, (Q - (length(t) - 1))/(1/vMA - sum(1/sei^4)*vMA)))

    ## estimate both parameters
    if (is.null(theta) & is.null(tau)) {
        optFun <- function(par) {
            -marglik(yi = yi, sei = sei, theta = par[1], tau = par[2],
                     log = TRUE, thetaLim = thetaLim, ... = ...)
        }
        res <- try(stats::optim(par = c(tMA, sqrt(tau2DL)), fn = optFun,
                                method = "L-BFGS-B", lower = c(thetaLim[1], 0),
                                upper = c(thetaLim[2], Inf))$par)
    } else if (!is.null(theta) & is.null(tau)) {
        ## estimate heterogeneity
        optFun <- function(par) {
            -marglik(yi = yi, sei = sei, theta = theta, tau = par, log = TRUE,
                     thetaLim = thetaLim, ... = ...)
        }
        res <- try(stats::optim(par = sqrt(tau2DL), fn = optFun,
                                method = "L-BFGS-B", lower = 0, upper = Inf)$par)

    } else if (is.null(theta) & !is.null(tau)) {
        ## estimate effect size
        optFun <- function(par) {
            -marglik(yi = yi, sei = sei, theta = par, tau = tau, log = TRUE,
                     thetaLim = thetaLim, ... = ...)
        }
        res <- try(stats::optim(par = tMA, fn = optFun, method = "L-BFGS-B",
                                lower = thetaLim[1], upper = thetaLim[2])$par)

    } else {
        stop("either 'theta', 'tau', or both need to be NULL")
    }

    if (inherits(res, "try-error")) {
        out <- NaN
    } else {
        out <- res
        names(out) <- c("theta", "tau")[c(is.null(theta), is.null(tau))]
    }
    return(out)
}
