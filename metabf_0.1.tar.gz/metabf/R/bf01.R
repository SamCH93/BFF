#' @title Normal-normal hierarchical model Bayes factor
#'
#' @description Compute the Bayes factor contrasting two hypotheses regarding
#'     the effect size and heterogeneity standard deviation in the normal-normal
#'     hierarchical model for the observed data.
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param theta0 Prior for effect size under the null hypothesis. Can be a
#'     numeric (a point prior) or a prior density function (a continuous prior
#'     distribution).
#' @param tau0 Prior for heterogeneity standard deviation under the null
#'     hypothesis. Can be a scalar (a point prior) or a prior density function
#'     (a continuous prior distribution).
#' @param theta1 Prior for effect size under the alternative hypothesis. Can be
#'     a numeric (a point prior) or a prior density function (a continuous prior
#'     distribution).
#' @param tau1 Prior for heterogeneity standard deviation under the alternative
#'     hypothesis. Can be a scalar (a point prior) or a prior density function
#'     (a continuous prior distribution).
#' @param log Logical indicating whether the log Bayes factor should be
#'     returned. Defaults to \code{FALSE}.
#' @param thetaLim Integration limits for theta. It is only recommended to
#'     change this argument if a prior distribution truncated to some interval
#'     is specified. Defaults to \code{c(-Inf, Inf)}.
#' @param ... Additional arguments passed to \code{stats::integrate}.
#'
#' @return The (log) Bayes factor (in favor of the null hypothesis).
#'
#' @author Samuel Pawel
#'
#' @examples
#' ## MD example from Grande et al. (2015)
#' yi <- c(-3.4, -0.95, -2.1, -1)
#' CIlower <- c(-6.47, -1.48, -4.25, -2.3)
#' CIupper <- c(-0.33, -0.42, 0.05, 0.3)
#' sei <- (CIupper - CIlower)/2/qnorm(p = 0.975)
#' labels <- c("Nieman (1990)", "Ciloglu (2005)", "Barrett (2012)", "Sloan (2013)")
#'
#' ## point null vs. point alternative (i.e., a likelihood ratio)
#' bf01(yi = yi, sei = sei, theta0 = 0, tau0 = 0, theta1 = 0.5, tau1 = 0)
#'
#' ## H0: theta = 0 and tau ~ half-normal(sd = 0.5)
#' ## H1: theta ~ normal(mean 0, sd = 2) and tau ~ half-normal(sd = 0.5)
#' bf01(yi = yi, sei = sei, theta0 = 0, tau0 = function(x) dnorm(x, sd = 0.5)*2,
#'      theta1 = function(x) dnorm(x, sd = 2), tau1 = function(x) dnorm(x)*2)
#'
#' @export
bf01 <- function(yi, sei, theta0, tau0, theta1, tau1, log = FALSE,
                 thetaLim = c(-Inf, Inf), ...) {

    ## input checks
    stopifnot(is.logical(log),
              !is.na(log)
              )

    logf0 <- marglik(yi = yi, sei = sei, theta = theta0, tau = tau0, log = TRUE,
                     thetaLim = thetaLim, ... = ...)
    logf1 <- marglik(yi = yi, sei = sei, theta = theta1, tau = tau1, log = TRUE,
                     thetaLim = thetaLim, ... = ...)
    logbf01 <- logf0 - logf1

    if (log == TRUE) {
        return(logbf01)
    } else {
        return(exp(logbf01))
    }
}
