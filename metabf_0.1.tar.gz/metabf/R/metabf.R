#' @title Meta-analysis via Bayes factors for Normal-Normal Hierarchical Models
#'
#' @description Function to compute Bayes factors, Bayes factor curves, maximum
#'     evidence estimates, and support intervals for effect size and
#'     heterogeneity parameters in normal-normal hierarchical meta-analysis
#'     model.
#'
#' @details The normal-normal hierarchical model assumes that an
#'     observed effect estimate \code{yi} is normally distributed around an
#'     overall effect size \eqn{\theta}{theta} with variance equal to the sum of
#'     its squared standard error \eqn{\code{sei}^2}{sei^2} and a heterogeneity
#'     variance \eqn{\tau^2}, i.e., \deqn{\code{yi}~|~\theta, \tau^2 \sim
#'     \mathrm{N}(\theta, \code{sei}^2 + \tau^2).}{yi | theta, tau^2 ~ N(theta,
#'     sei^2 + tau^2).}
#'
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param labels Vector of length n with the study labels.
#' @param theta0 Prior for effect size in case it is a nuisance parameter. Can
#'     be a numeric (a point prior) or a prior density function (a continuous
#'     prior distribution).
#' @param tau0 Prior for heterogeneity standard deviation in case it is a
#'     nuisance parameter. Can be a scalar (a point prior) or a prior density
#'     function (a continuous prior distribution).
#' @param theta1 Prior for effect size under the alternative. Can be a numeric
#'     (a point prior) or a prior density function (a continuous prior
#'     distribution). Defaults to the same prior as specified for \code{theta0}.
#' @param tau1 Prior for heterogeneity standard deviation under the alternative.
#'     Can be a scalar (a point prior) or a prior density function (a continuous
#'     prior distribution). Defaults to the same prior as specified for
#'     \code{tau0}.
#' @param k Level of the support intervals. Defaults to \code{1}.
#' @param control A list with control arguments for \code{marglik},
#'     \code{supinttheta}, \code{supinttau}, \code{stats::integrate}, and
#'     \code{stats::uniroot}.
#'
#' @return An object of class \code{"metabf"}, which is a list containing the
#'     following components:
#' \tabular{ll}{
#'    \code{yi} \tab The supplied effect estimates \cr
#'    \tab \cr
#'    \code{sei} \tab The supplied standard errors \cr
#'    \tab \cr
#'    \code{labels} \tab The labels (either supplied or automatically generated) \cr
#'    \tab \cr
#'    \code{k} \tab The supplied support level \cr
#'    \tab \cr
#'    \code{theta0} \tab The supplied prior for the effect size under the null \cr
#'    \tab \cr
#'    \code{theta1} \tab The supplied prior for the effect size under the alternative \cr
#'    \tab \cr
#'    \code{tau0} \tab The supplied prior for the heterogeneity SD under the null \cr
#'    \tab \cr
#'    \code{tau1} \tab The supplied prior for the heterogeneity SD under the alternative \cr
#'    \tab \cr
#'    \code{MEEjoint} \tab The joint maximum evidence estimate (MEE) for effect size and heterogeneity standard deviation \cr
#'    \tab \cr
#'    \code{MEEtheta} \tab The marginal MEE for the effect size \cr
#'    \tab \cr
#'    \code{MEEtau} \tab The marginal MEE for the heterogeneity standard deviation \cr
#'    \tab \cr
#'    \code{kjoint} \tab The joint MEE evidence level, i.e., Bayes factor evaluated at the MEE \cr
#'    \tab \cr
#'    \code{ktheta} \tab The marginal MEE evidence level (effect size) \cr
#'    \tab \cr
#'    \code{ktau} \tab The marginal MEE evidence level (heterogeneity) \cr
#'    \tab \cr
#'    \code{SItheta} \tab The k support interval for the effect size \cr
#'    \tab \cr
#'    \code{SItau} \tab The k support interval for the heterogeneity standard deviation \cr
#'    \tab \cr
#'    \code{BF01joint} \tab The joint Bayes factor curve  \cr
#'    \tab \cr
#'    \code{BF01theta} \tab The marginal Bayes factor curve (effect size) \cr
#'    \tab \cr
#'    \code{BF01tau} \tab The marginal Bayes factor curve (heterogeneity) \cr
#' }
#'
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' ## Below examples that were reanalyzed in Röver et al. (2021)
#' ## doi.org/10.1002/jrsm.1475
#'
#' ## SMD example from Aalbers et al. (2017)
#' ## doi.org/10.1002/14651858.CD004517.pub3
#' yi <- c(-2.03, -0.58, -0.75, -0.56)
#' CIlower <- c(-2.61, -1.1, -1.57, -1.05)
#' CIupper <- c(-1.44, -0.07, 0.08, -0.07)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Chen (1992)", "Radulovic (1996)", "Albornoz (2011)", "Erkkilä (2011)")
#' ma1 <- metabf(yi = yi, sei = sei,
#'               theta1 = function(x) dnorm(x = x, mean = 0, sd = 2),
#'               tau1 = function(x) dnorm(x = x, mean = 0, sd = 0.5)*2)
#' ma1
#' plot(x = ma1, tauRange = c(0, 2), cex.label = 0.6)
#'
#' ## MD example from Grande et al. (2015)
#' ## doi.org/10.1002/14651858.CD010596.pub2
#' yi <- c(-3.4, -0.95, -2.1, -1)
#' CIlower <- c(-6.47, -1.48, -4.25, -2.3)
#' CIupper <- c(-0.33, -0.42, 0.05, 0.3)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Nieman (1990)", "Ciloglu (2005)", "Barrett (2012)", "Sloan (2013)")
#' ma2 <- metabf(yi = yi, sei = sei,
#'               theta1 = function(x) dnorm(x = x, mean = 0, sd = 4),
#'               tau1 = function(x) dnorm(x = x, mean = 0, sd = 0.5)*2)
#' ma2
#' plot(ma2, tauRange = c(0, 2), cex.label = 0.6)
#'
#' ## logOR example from Crins et al. (2014)
#' ## doi.org/10. 1111/petr.12362
#' yi <- c(-2.31, -1.26)
#' CIlower <- c(-3.48, -1.13)
#' CIupper <- c(-2.52, -0.00)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Heffron (2003)", "Spada (2006)")
#' ma3 <- metabf(yi = yi, sei = sei,
#'               theta1 = function(x) dnorm(x = x, mean = 0, sd = 2),
#'               tau1 = function(x) dnorm(x = x, mean = 0, sd = 0.5)*2)
#' ma3
#' plot(ma3, thetaRange = c(-3.5, 0), tauRange = c(0, 4), cex.label = 0.6)
#'
#'
#' ## logIRR example from Anker (2018)
#' ## doi.org/10.1002/ejhf.823
#' yi <- c(-0.82, -0.39, 0.09, -0.14)
#' CIlower <- c(-1.53, -0.96, -1.55, -2.64)
#' CIupper <- c(-0.12, 0.19, 1.72, 2.36)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("FAIR-HF (2009)", "CONFIRM-HF (2015)", "EFFICACY-HF (2015)",
#'               "FER-CARS-01 (2018)")
#' ma4 <- metabf(yi = yi, sei = sei,
#'               theta1 = function(x) dnorm(x = x, mean = 0, sd = 2),
#'               tau1 = function(x) dnorm(x = x, mean = 0, sd = 0.5)*2)
#' ma4
#' plot(ma4, tauRange = c(0, 1.5), cex.label = 0.5)
#'
#' ## log Odds example from Neuenschwander et al. (2010)
#' yi <- c(-1.79, -1.74, -2.81, -2.12)
#' CIlower <- c(-2.5, -2.25, -3.57, -2.97)
#' CIupper <- c(-1.09, -1.24, -2.04, -1.27)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Feagan (2005)", "Rutgeerts (2005a)", "Rutgeerts (2005b)",
#'                "Van Assche (2006)")
#' ma5 <- metabf(yi = yi, sei = sei,
#'               theta1 = function(x) dnorm(x = x, mean = 0, sd = 2),
#'               tau1 = function(x) dnorm(x = x, mean = 0, sd = 1)*2)
#' ma5
#' plot(ma5, tauRange = c(0, 1.5), cex.label = 0.5)
#' }
#'
#' @export
metabf <- function(yi, sei, labels = names(yi), theta1, tau1, theta0 = theta1,
                   tau0 = tau1, k = 1,
                   control = list(thetaLim = c(-Inf, Inf),
                                  thetaSEmultSearch = 5,
                                  tauUpperSearch = 5,
                                  subdivisions = 100L,
                                  rel.tol = .Machine$double.eps^0.25,
                                  abs.tol = .Machine$double.eps^0.25,
                                  tol = .Machine$double.eps^0.25,
                                  maxiter = 1000)) {

    ## function call
    call <- match.call()

    ## study labels
    stopifnot(is.null(labels) |
              (is.character(labels) & length(labels) == length(yi)))
    if (is.null(labels)) {
        labels <- paste("Estimate", seq(from = 1, to = length(yi), by = 1))
    }

    ## joint inferences for tau and theta
    meejoint <- mee(yi = yi, sei = sei, subdivisions = control$subdivisions,
                    thetaLim = control$thetaLim, rel.tol = control$rel.tol,
                    abs.tol = control$abs.tol) # joint
    kjoint <- bf01(yi = yi, sei = sei, theta0 = meejoint[1], tau0 = meejoint[2],
                   theta1 = theta1, tau1 = tau1,
                   thetaLim = control$thetaLim,
                   subdivisions = control$subdivisions,
                   rel.tol = control$rel.tol, abs.tol = control$abs.tol)
    kjoint <- unname(kjoint)
    ## HACK implement more robust vectorized version in bf01 (avoiding computing
    ## the same normalizing constant multiple times)
    logdenomjoint <- marglik(yi = yi, sei = sei, theta = theta1, tau = tau1,
                             log = TRUE, thetaLim = control$thetaLim,
                             subdivisions = control$subdivisions,
                             rel.tol = control$rel.tol,
                             abs.tol = control$abs.tol)
    bf01joint. <- function(theta, tau, log = FALSE) {
        lognumjoint <- marglik(yi = yi, sei = sei, theta = theta, tau = tau,
                               log = TRUE, thetaLim = control$thetaLim,
                               subdivisions = control$subdivisions,
                               rel.tol = control$rel.tol,
                               abs.tol = control$abs.tol)
        logbfjoint <- lognumjoint - logdenomjoint
        if (log == TRUE) return(logbfjoint)
        else return(exp(logbfjoint))
    }
    bf01joint <- Vectorize(FUN = bf01joint., vectorize.args = c("theta", "tau"))

    ## marginal inferences for theta
    sitheta <- supinttheta(yi = yi, sei = sei, k = k, tau0 = tau0,
                           theta1 = theta1, tau1 = tau1,
                           thetaSEmultSearch = control$thetaSEmultSearch,
                           thetaLim = control$thetaLim,
                           tol = control$tol,
                           maxiter = control$maxiter,
                           subdivisions = control$subdivisions,
                           rel.tol = control$rel.tol, abs.tol = control$abs.tol)
    meetheta <- unname(sitheta[2])
    ktheta <- bf01(yi = yi, sei = sei, theta0 = meetheta, tau0 = tau0,
                   theta1 = theta1, tau1 = tau1,
                   thetaLim = control$thetaLim,
                   subdivisions = control$subdivisions,
                   rel.tol = control$rel.tol, abs.tol = control$abs.tol)
    ## HACK implement more robust vectorized version in bf01 (avoiding computing
    ## the same normalizing constant multiple times)
    logdenomtheta <- marglik(yi = yi, sei = sei, theta = theta1, tau = tau1,
                             log = TRUE,
                             thetaLim = control$thetaLim,
                             subdivisions = control$subdivisions,
                             rel.tol = control$rel.tol,
                             abs.tol = control$abs.tol)
    bf01theta. <- function(theta, log = FALSE) {
        lognumtheta <- marglik(yi = yi, sei = sei, theta = theta, tau = tau0,
                               log = TRUE,
                               thetaLim = control$thetaLim,
                               subdivisions = control$subdivisions,
                               rel.tol = control$rel.tol,
                               abs.tol = control$abs.tol)
        logbftheta <- lognumtheta - logdenomtheta
        if (log == TRUE) return(logbftheta)
        else return(exp(logbftheta))
    }
    bf01theta <- Vectorize(FUN = bf01theta., vectorize.args = "theta")

    ## marginal inferences for tau
    sitau <- supinttau(yi = yi, sei = sei, k = k, theta0 = theta0, theta1 = theta1,
                       tau1 = tau1,
                       tauUpperSearch = control$tauUpperSearch,
                       thetaLim = control$thetaLim,
                       tol = control$tol, maxiter = control$maxiter,
                       subdivisions = control$subdivisions,
                       rel.tol = control$rel.tol, abs.tol = control$abs.tol)
    meetau <- unname(sitau[2])
    ktau <- bf01(yi = yi, sei = sei, theta0 = theta0, tau0 = meetau,
                 theta1 = theta1, tau1 = tau1,
                 thetaLim = control$thetaLim,
                 subdivisions = control$subdivisions, rel.tol = control$rel.tol,
                 abs.tol = control$abs.tol)
    ## HACK implement more robust vectorized version in bf01 (avoiding computing
    ## the same normalizing constant multiple times)
    logdenomtau <- marglik(yi = yi, sei = sei, theta = theta1, tau = tau1,
                           log = TRUE,
                           thetaLim = control$thetaLim,
                           subdivisions = control$subdivisions,
                           rel.tol = control$rel.tol, abs.tol = control$abs.tol)
    bf01tau. <- function(tau, log = FALSE) {
        lognumtau <- marglik(yi = yi, sei = sei, theta = theta0, tau = tau,
                             log = TRUE,
                             thetaLim = control$thetaLim,
                             subdivisions = control$subdivisions,
                             rel.tol = control$rel.tol,
                             abs.tol = control$abs.tol)
        logbftau <- lognumtau - logdenomtau
        if (log == TRUE) return(logbftau)
        else return(exp(logbftau))
    }
    bf01tau <- Vectorize(FUN = bf01tau., vectorize.args = "tau")

    ## output object
    out <- list("yi" = yi,
                "sei" = sei,
                "labels" = labels,
                "k" = k,
                "theta0" = theta0,
                "theta1"= theta1,
                "tau0" = tau0,
                "tau1" = tau1,
                "MEEjoint" = meejoint,
                "MEEtheta" = meetheta,
                "MEEtau" = meetau,
                "kjoint" = kjoint,
                "ktheta" = ktheta,
                "ktau" = ktau,
                "SItheta" = sitheta,
                "SItau" = sitau,
                "BF01joint" = bf01joint,
                "BF01theta" = bf01theta,
                "BF01tau" = bf01tau,
                "call" = call)
    class(out) <- "metabf"
    invisible(out)
}


#' Print method for class \code{"metabf"}
#' @method print metabf
#'
#' @description Prints information related to a \code{"metabf"} object
#'
#' @param x Object of class \code{"metabf"}
#' @param digits Number of digits
#' @param ... Other arguments (for consistency with the generic)
#'
#' @return Prints text summary in the console and invisibly returns the
#'     \code{"metabf"} object
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' ## SMD example from Aalbers et al. (2017)
#' ## doi.org/10.1002/14651858.CD004517.pub3
#' yi <- c(-2.03, -0.58, -0.75, -0.56)
#' CIlower <- c(-2.61, -1.1, -1.57, -1.05)
#' CIupper <- c(-1.44, -0.07, 0.08, -0.07)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Chen (1992)", "Radulovic (1996)", "Albornoz (2011)", "Erkkilä (2011)")
#' aalbersMA <- metabf(yi = yi, sei = sei,
#'                     theta1 = function(x) dnorm(x, mean = 0, sd = 1),
#'                     tau1 = function(x) dnorm(x, mean = 0, sd = 0.5)*2)
#' print(aalbersMA)
#' }
#' @export

print.metabf <- function(x, digits = 4, ...) {
    cat(paste0("\nBayes factor meta-analysis (n = ", length(x$yi)," estimates)\n\n"))

    cat("Call:\n")
    print(x$call)
    cat("\n")

    cat("Bayes factor inferences:\n")
    mee <- c(signif(x$MEEtheta, digits = digits),
             signif(x$MEEtau, digits = digits),
             signif(x$MEEjoint[1], digits = digits),
             signif(x$MEEjoint[2], digits = digits)
             ## paste(signif(x$MEEjoint, digits = digits), collapse = ",")
             )
    bf01mee <- formatBF(BF = c(x$ktheta, x$ktau, x$kjoint, x$kjoint))
    bf01zero <- formatBF(BF = c(x$BF01theta(theta = 0),
                                x$BF01tau(tau = 0),
                                x$BF01joint(theta = 0, tau = 0),
                                x$BF01joint(theta = 0, tau = 0)))
    resultsDF <- data.frame(mee,
                            bf01mee,
                            c(signif(x$SItheta[1], digits = digits),
                              signif(x$SItau[1], digits = digits),
                              ".",
                              "."),
                            c(signif(x$SItheta[3], digits = digits),
                              signif(x$SItau[3], digits = digits),
                              ".",
                              "."),
                            bf01zero)
    colnames(resultsDF) <- c("MEE", "BF01(MEE)",
                             paste0("lowSI(k=",  x$k, ")"),
                             paste0("uppSI(k=",  x$k, ")"),
                             "BF01(0)")
    rownames(resultsDF) <- c("-Effect size (marginal)",
                             "-Heterogeneity SD (marginal)",
                             "-Effect size (joint)",
                             "-Heterogeneity SD (joint)")
    print(resultsDF)


    cat("\n")
    invisible(x)
}

#' Summary method for class \code{"metabf"}
#' @method summary metabf
#'
#' @description Prints detailed information related to a \code{"metabf"} object
#'
#' @param object Object of class \code{"metabf"}
#' @param ... Arguments passed to \code{print.metabf}
#'
#' @return Prints detailed text summary in the console and invisibly returns the
#'     \code{"metabf"} object
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' ## SMD example from Aalbers et al. (2017)
#' ## doi.org/10.1002/14651858.CD004517.pub3
#' yi <- c(-2.03, -0.58, -0.75, -0.56)
#' CIlower <- c(-2.61, -1.1, -1.57, -1.05)
#' CIupper <- c(-1.44, -0.07, 0.08, -0.07)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Chen (1992)", "Radulovic (1996)", "Albornoz (2011)", "Erkkilä (2011)")
#' aalbersMA <- metabf(yi = yi, sei = sei,
#'                     theta1 = function(x) dnorm(x, mean = 0, sd = 1),
#'                     tau1 = function(x) dnorm(x, mean = 0, sd = 0.5)*2)
#' summary(aalbersMA)
#' }
#' @export

summary.metabf <- function(object, ...) {

    print(object, ... = ...)

    cat("Priors:\n")
    cat("-Effect size as nuisance parameter under H0\n")
    if (is.function(object$theta0)) {
        print(object$theta0)
    } else {
        cat(paste("theta =", object$theta0), "\n")
    }
    cat("-Effect size under H1\n")
    if (is.function(object$theta1)) {
        print(object$theta1)
    } else {
        cat(paste("theta =", object$theta1), "\n")
    }
    cat("-Heterogeneity SD as nuisance parameter under H0\n")
    if (is.function(object$tau0)) {
        print(object$tau0)
    } else {
        cat(paste("theta =", object$tau0), "\n")
    }
    cat("-Heterogeneity SD under H1\n")
    if (is.function(object$tau1)) {
        print(object$tau1)
    } else {
        cat(paste("theta =", object$tau1), "\n")
    }

    cat("\n")
    invisible(object)
}



#' Plot method for class \code{"metabf"}
#' @method plot metabf
#'
#' @description Plots data, support curves, and support intervals from a
#'     \code{"metabf"} object.
#'
#' @param x Object of class \code{"metabf"}
#' @param plot Logical indicating whether the a plot should be produced. If
#'     \code{FALSE}, only the data underlying the plot are returned. Defaults to
#'     \code{TRUE}.
#' @param thetaRange Range of effect sizes for which plots are drawn. Defaults
#'     to the minimum effect estimate - 2 standard errors to the maximum effect
#'     estimate + 2 standard errors.
#' @param tauRange Range of heterogeneity standard deviations for which plots
#'     are drawn. Defaults to the range from \code{0} to \code{1}.
#' @param ngrid Number of grid points to compute the plots. Defaults to
#'     \code{100}.
#' @param cex.label Scaling factor of the study labels. Defaults to \code{1}.
#' @param ... Other arguments (for consistency with the generic).
#'
#' @return Plots data, joint support surface, and marginal support curves.
#'     Invisibly returns a list with the data for the plots.
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' ## SMD example from Aalbers et al. (2017)
#' ## doi.org/10.1002/14651858.CD004517.pub3
#' yi <- c(-2.03, -0.58, -0.75, -0.56)
#' CIlower <- c(-2.61, -1.1, -1.57, -1.05)
#' CIupper <- c(-1.44, -0.07, 0.08, -0.07)
#' sei <- (CIupper - CIlower)/(2*qnorm(p = 0.975))
#' names(yi) <- c("Chen (1992)", "Radulovic (1996)", "Albornoz (2011)", "Erkkilä (2011)")
#' aalbersMA <- metabf(yi = yi, sei = sei,
#'                     theta1 = function(x) dnorm(x = x, mean = 0, sd = 2),
#'                     tau1 = function(x) dnorm(x = x, mean = 0, sd = 0.5)*2)
#' aalbersMA
#' plot(aalbersMA, tauRange = c(0, 2), cex.label = 0.6)
#' }
#'
#' @export
plot.metabf <- function(x,
                        plot = TRUE,
                        thetaRange = c(min(x$yi - 2*x$sei), max(x$yi + 2*x$sei)),
                        tauRange = c(0, 1),
                        ngrid = 100,
                        cex.label = 1,
                        ...) {

    ## input checks
    stopifnot(is.logical(plot),
              !is.na(plot),

              is.numeric(thetaRange),
              length(thetaRange) == 2,
              all(is.finite(thetaRange)),
              thetaRange[2] > thetaRange[1],

              is.numeric(tauRange),
              length(tauRange) == 2,
              all(is.finite(tauRange)),
              tauRange[2] > tauRange[1]
              )

    if (plot == TRUE) {
        oldpar <- graphics::par(no.readonly = TRUE)
        on.exit(graphics::par(oldpar))
        graphics::par(mfrow = c(2, 2),
                      mar = c(5.1, 5.5, 4.1, 2.1))
        transpRed <- grDevices::adjustcolor(col = 2, alpha.f = 0.8)
    }

    ## forest plot
    yi <- x$yi
    sei <- x$sei
    labels <- x$labels
    forestDF <- data.frame(yi = yi, sei = sei,
                           lower = yi - stats::qnorm(p = 0.975)*sei,
                           upper = yi + stats::qnorm(p = 0.975)*sei,
                           labels = labels)
    if (plot == TRUE) {
        ybreaks <- seq(length(yi), 1, -1)
        plot(x = yi, y = ybreaks, type = "n", xlim = thetaRange, yaxt = "n",
             ylim = c(0.5, length(yi) + 0.5),
             xlab = "Effect estimate with 95% CI", ylab = "",
             panel.first = graphics::grid(ny = NA, lty = 3),
             main = "Forest plot of data"
             )
        graphics::axis(side = 2, at = ybreaks, labels = labels, las = 2,
                       cex.axis = cex.label)
        graphics::arrows(x = forestDF$lower, x1 = forestDF$upper, y0 = ybreaks,
                         angle = 90, code = 3, length = 0)
        graphics::points(x = yi, y = ybreaks, pch = 20, cex = 1.5)
    }

    ## BF contour plot for tau and theta
    thetaseq <- seq(from = thetaRange[1], to = thetaRange[2], length.out = ngrid)
    tauseq <- seq(tauRange[1], tauRange[2], length.out = ngrid)
    applyGrid <- expand.grid(theta = thetaseq, tau = tauseq)
    bf <- x$BF01joint(theta = applyGrid$theta, tau = applyGrid$tau)
    contourDF <- data.frame(applyGrid, bf = bf)
    if (plot == TRUE) {
        bfMatrix <- matrix(contourDF$bf, ncol = ngrid, byrow = TRUE)
        graphics::image(x = tauseq, y = thetaseq, z = bfMatrix,
                        col = grDevices::hcl.colors(n = 100, palette = "Blues 3", rev = TRUE),
                        las = 1, xlab = bquote("Heterogeneity SD"),
                        ylab = bquote("Effect size"),
                        main = bquote(bold("Joint Bayes factor"))
                        )
        graphics::contour(x = tauseq, y = thetaseq, z = bfMatrix,
                          levels = c(1/100, 1/10, 3, 10, 30, 100), add = TRUE,
                          col = "#00000080", lty = 3)
        graphics::contour(x = tauseq, y = thetaseq, z = bfMatrix, levels = 1,
                          add = TRUE, col = "#00000080", lty = 2, lwd = 1.5)
        graphics::contour(x = tauseq, y = thetaseq, z = bfMatrix, levels = x$k,
                          add = TRUE, col = transpRed, lty = 2, lwd = 1.5)
        graphics::points(x = x$MEEjoint[2], y = x$MEEjoint[1], pch = 20, col = 2)
    }

    ## BF curve for theta
    bf <- x$BF01theta(theta = thetaseq)
    thetaDF <- data.frame(theta = thetaseq, bf = bf)
    if (plot == TRUE) {
        plot(x = thetaseq, y = bf, xlim = thetaRange, type = "l", log = "y",
             xlab = bquote("Effect size"), ylab = "Bayes factor",
             main = bquote(bold("Marginal Bayes factor")),
             panel.first = graphics::grid(lty = 3, equilogs = FALSE), las = 1)
        graphics::abline(h = 1, lwd = 1.5, lty = 2, col = "#00000080")
        graphics::abline(h = x$k, lwd = 1.5, lty = 2, col = transpRed)
        graphics::arrows(x0 = x$SItheta[1], x1 = x$SItheta[3], y0 = x$ktheta, cex = 1.5,
                         col = transpRed, code = 3, angle = 90, length = 0)
        graphics::points(x = x$MEEtheta, y = x$ktheta, pch = 20, col = transpRed)
    }

    ## BF curve for tau
    bf <- x$BF01tau(tau = tauseq)
    tauDF <- data.frame(tau = tauseq, bf = bf)
    if (plot == TRUE) {
        plot(x = tauseq, y = bf, xlim = tauRange, type = "l", log = "y",
             xlab = bquote("Heterogeneity SD"), ylab = "Bayes factor",
             main = bquote(bold("Marginal Bayes factor")),
             panel.first = graphics::grid(lty = 3, equilogs = FALSE), las = 1)
        graphics::abline(h = 1, lwd = 1.5, lty = 2, col = "#00000080")
        graphics::abline(h = x$k, lwd = 1.5, lty = 2, col = transpRed)
        graphics::arrows(x0 = x$SItau[1], x1 = x$SItau[3], y0 = x$ktau, cex = 1.5,
                         col = transpRed, code = 3, angle = 90, length = 0)
        graphics::points(x = x$MEEtau, y = x$ktau, pch = 20, col = 2)
    }

    res <- list("forestDF" = forestDF, "contourDF" = contourDF,
                "thetaDF" = thetaDF, "tauDF" = tauDF,
                "MEEtau" = x$SItau, "MEEtheta" = x$SItheta,
                "MEEjoint" = x$MEEjoint)
    invisible(res)
}




## non-vectorized version of formatBF
.formatBF <- function(BF, digits = "default") {
    ## check inputs
    stopifnot(
        length(BF) == 1,
        is.numeric(BF),
        (0 <= BF) || is.na(BF),

        length(digits) == 1,
        (is.character(digits) && digits == "default") ||
        (is.numeric(digits) && 0 <= digits)
    )

    ## return NA if input NA
    if (is.na(BF) || is.nan(BF)) {
        result <- NA
    } else {
        ## format BF
        if (digits == "default") {
            if (BF < 1/1000)
                result <- "< 1/1000"
            if ((BF >= 1/1000) && (BF <= 1/10))
                result <- paste0("1/", as.character(round(1/BF)))
            if ((BF > 1/10) && (BF < 1))
                result <- paste0("1/", as.character(round(1/BF, digits = 1)))
            if ((BF < 10) && (BF >= 1))
                result <- as.character(round(BF, digits = 1))
            if ((BF >= 10) && (BF <= 1000))
                result <- as.character(round(BF))
            if (BF > 1000)
                result <- "> 1000"
        } else {
            if (BF < 1) {
                result <- paste0("1/", as.character(round(1/BF, digits = digits)))
            } else {
                result <- as.character(round(BF, digits = digits))
            }
        }
        ## when 1/1 return 1
        if (result == "1/1") result <- "1"
    }
    return(result)
}

#' @title Formatting of Bayes factors
#'
#' @description Formats Bayes factors such that Bayes factors smaller than 1 are
#'     represented as ratios \eqn{1/x}, where \eqn{x} is rounded to the
#'     specified number of digits, while Bayes factors larger than 1 are only
#'     rounded to the specified number of digits.
#'
#' @param BF Bayes factor
#' @param digits either \code{"default"} (see Details) or a positive integer
#'     specifiying the number of decimal places to round the Bayes factor (for
#'     Bayes factors \eqn{\geq 1}{>= 1}) or its inverse (for Bayes factors
#'     \eqn{< 1}{< 1})
#'
#' @return A character vector of ratios (for inputs \eqn{< 1}{< 1}) or rounded
#'     numeric values (for inputs \eqn{\geq 1}{>= 1}) ).
#'
#' @details The default formatting, which is recommended in Held and Ott (2018),
#'     is as follows: For very small Bayes factors BF < 1/1000, "< 1/1000" is
#'     returned. Bayes factors BF with 1/1000 \eqn{\leq}{<=} BF \eqn{\leq}{<=}
#'     1/10 are formatted as \eqn{1/x} where \eqn{x} is an integer and Bayes
#'     factors BF with \eqn{1/10} \eqn{<} BF \eqn{<} 1 as \eqn{1/x}, where
#'     \eqn{x} is rounded to one decimal place. Accordingly, Bayes factors
#'     \eqn{\leq}{<=} BF \eqn{<} 10 are rounded to one decimal place, Bayes
#'     factors 10 \eqn{\leq}{<=} BF \eqn{\leq}{<=} 1000 are rounded to the next
#'     integer and for larger Bayes factors, "> 1000" is returned.
#'
#' If digits is specified, the Bayes factor (if it is \eqn{\geq}{>=} 1) or its
#' inverse (if the Bayes factor is \eqn{<} 1) is rounded to the number of
#' decimal places specified and returned as a ratio if the Bayes factor is
#' \eqn{<} 1.
#'
#' @references Held, L. and Ott, M. (2018). On \eqn{p}-values and Bayes factors.
#'     Annual Review of Statistics and Its Application, 5, 393-419.
#'     \doi{10.1146/annurev-statistics-031017-100307}
#'
#' @author Manuela Ott (creator of package \code{pCalibrate}), Leonhard Held
#'     (contributor of package \code{pCalibrate}), Samuel Pawel (made small
#'     changes to \code{pCalibrate::formatBF})
#'
#' @noRd
formatBF <- Vectorize(.formatBF)
