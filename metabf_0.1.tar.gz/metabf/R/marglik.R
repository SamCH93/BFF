#' @title Marginal likelihood
#'
#' @description Compute the marginal likelihood of effect estimates based on
#'     normal-normal hierarchical model.
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param theta Prior for effect size. Can be a numeric (a point prior) or a
#'     prior density function (a continuous prior distribution).
#' @param tau Prior for heterogeneity standard deviation. Can be a scalar (a
#'     point prior) or a prior density function (a continuous prior
#'     distribution).
#' @param log Logical indicating whether the log marginal likelihood should be
#'     returned. Defaults to \code{FALSE}.
#' @param thetaLim Integration limits for theta. It is only recommended to
#'     change this argument if a prior distribution truncated to some interval
#'     is specified. Defaults to \code{c(-Inf, Inf)}.
#' @param ... Additional arguments passed to \code{stats::integrate}.
#'
#' @return The (log) marginal likelihood
#'
#' @author Samuel Pawel
#'
#' @examples
#' yi <- c(0.5, 0.3, 0.1, 0.4)
#' sei <- c(0.05, 0.06, 0.1, 0.03)
#'
#' ## likelihood
#' marglik(yi = yi, sei = sei, theta = 0, tau = 0.5)
#'
#' ## prior on heterogeneity
#' marglik(yi = yi, sei = sei, theta = 0, tau = function(x) dnorm(x = x)*2)
#'
#' ## prior on effect size
#' marglik(yi = yi, sei = sei, theta = function(x) dnorm(x), tau = 0.3)
#'
#' ## prior on both
#' marglik(yi = yi, sei = sei, theta = function(x) dnorm(x),
#'         tau = function(x) dnorm(x = x, sd = 0.5)*2)
#'
#' @export
marglik <- function(yi, sei, theta, tau, log = FALSE,
                    thetaLim = c(-Inf, Inf), ...) {

     ## input checks
    stopifnot(is.numeric(yi),
              length(yi) > 0,
              all(is.finite(yi)),

              is.numeric(sei),
              length(sei) == 1 || length(sei) == length(yi),
              all(is.finite(sei)),
              all(sei > 0),

              is.numeric(theta) || is.function(theta),

              is.numeric(tau) || is.function(tau),

              is.logical(log),
              !is.na(log),

              is.numeric(thetaLim),
              length(thetaLim) == 2,
              thetaLim[2] > thetaLim[1]
              )

    ## likelihood
    lik. <- function(th, ta, log = FALSE) {
        if (log == TRUE) {
            sum(stats::dnorm(x = yi, mean = th, sd = sqrt(sei^2 + ta^2), log = TRUE))
        } else {
            prod(stats::dnorm(x = yi, mean = th, sd = sqrt(sei^2 + ta^2)))
        }
    }
    lik <- Vectorize(FUN = lik.)

    ## point priors
    if (is.numeric(theta) & is.numeric(tau)) {
        out <- lik(th = theta, ta = tau, log = log)
    } else {
        if (is.numeric(theta) & is.function(tau)) {
            ## prior on tau
            intFun <- function(par) lik(th = theta, ta = par)*tau(par)
            res <- try(stats::integrate(f = intFun, lower = 0, upper = Inf,
                                        ... = ...)$value)
            if (inherits(res, "try-error")) {
                out <- NaN
            } else {
                out <- res
            }
        } else if (is.function(theta) & is.numeric(tau)) {
            ## prior on theta
            intFun <- function(par) lik(th = par, ta = tau)*theta(par)
            res <- try(stats::integrate(f = intFun, lower = thetaLim[1],
                                        upper = thetaLim[2], ... = ...)$value)
            if (inherits(res, "try-error")) {
                out <- NaN
            } else {
                out <- res
            }
        } else if (is.function(theta) & is.function(tau)) {
            intFun <- function(par) {
                lik(th = par[1], ta = par[2])*theta(par[1])*tau(par[2])
            }
            res <- try(cubature::hcubature(f = intFun,
                                           lowerLimit = c(thetaLim[1], 0),
                                           upperLimit = c(thetaLim[2], Inf)
                                           )$integral)
            if (inherits(res, "try-error")) {
                out <- NaN
            } else {
                out <- res
            }
        } else {
            stop("'theta' and 'tau' need to be functions or numerics")
        }
        if (log == TRUE) {
            out <- log(out)
        }
    }
    return(out)
}
