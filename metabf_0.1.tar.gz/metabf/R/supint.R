#' @title Support interval for heterogeneity standard deviation
#'
#' @description Computes a support interval for the heterogeneity standard
#'     deviation in the normal-normal hierarchical model based on a set of
#'     observed effect estimates and standard errors.
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param k Level of the support interval. Defaults to \code{1}.
#' @param theta0 Prior for effect size nuisance parameter. Can be a numeric (a
#'     point prior) or a prior density function (a continuous prior
#'     distribution).
#' @param theta1 Prior for effect size under the alternative hypothesis. Can be
#'     a numeric (a point prior) or a prior density function (a continuous prior
#'     distribution). Defaults to the same prior as specified for \code{theta0}.
#' @param tau1 Prior for heterogeneity standard deviation under the alternative
#'     hypothesis. Can be a scalar (a point prior) or a prior density function
#'     (a continuous prior distribution).
#' @param tauUpperSearch Upper limit for numerical search of upper support
#'     interval limit (the lower limit is fixed to tau = 0). Defaults to
#'     \code{5}. Increase if there are numerical problems computing the support
#'     interval.
#' @param tol Argument passed to \code{stats::uniroot}. Defaults to
#'     \code{.Machine$double.eps^0.25}.
#' @param maxiter Argument passed to \code{stats::uniroot}. Defauls to
#'     \code{1000}.
#' @param thetaLim Integration limits for theta. It is only recommended to
#'     change this argument if a prior distribution truncated to some interval
#'     is specified. Defaults to \code{c(-Inf, Inf)}.
#' @param ... Additional arguments passed to \code{stats::integrate}.
#'
#' @return A k support interval for the heterogeneity standard deviation
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' yi <- c(0.5, 0.3, 0.1, 0.4)
#' sei <- c(0.05, 0.06, 0.1, 0.03)
#' ## k = 1 SI for heterogeneity standard deviation
#' supinttau(yi = yi, sei = sei, k = 1, theta0 = function(x) dnorm(x = x, sd = 2),
#'           tau1 = function(x) dnorm(x = x, sd = 0.5)*2)
#' }
#'
#' @export
supinttau <- function(yi, sei, k = 1, theta0, theta1 = theta0, tau1,
                      tauUpperSearch = 5, tol = .Machine$double.eps^0.25,
                      maxiter = 1000, thetaLim = c(-Inf, Inf), ...) {

    ## input checks
    stopifnot(is.numeric(k),
              length(k) == 1,
              is.finite(k),
              k > 0,

              is.numeric(theta0) || is.function(theta0)
              )


    meetau <- mee(yi = yi, sei = sei, theta = theta0, thetaLim = thetaLim,
                  ... = ...)
    kmee <- bf01(yi = yi, sei = sei, theta0 = theta0, tau0 = meetau,
                 theta1 = theta1, tau1 = tau1, thetaLim = thetaLim,
                 ... = ...)
    out <- c(NaN, meetau, NaN)
    names(out) <- c(paste0("Lower k=", k), paste0("MEE k=", signif(kmee, 3)),
                    paste0("Upper k=", k))
    if (k < kmee) {
        rootFun. <- function(par) {
            bf01(yi = yi, sei = sei, theta0 = theta0, tau0 = par,
                 theta1 = theta1, tau1 = tau1, thetaLim = thetaLim,
                 ... = ...) - k
        }
        rootFun <- Vectorize(FUN = rootFun.)

        if (rootFun(0) >= 0) {
            out[1] <- 0
        } else {
            low <- try(stats::uniroot(f = rootFun, interval = c(0, meetau),
                                      tol = tol, maxiter = maxiter)$root)
            if (!inherits(low, "try-error")) {
                out[1] <- low
            }
        }
        ##setauML <- (1/mean(1/se^2) + meetau^2)/sqrt(2*(length(t) - 1))
        upp <- try(stats::uniroot(f = rootFun,
                                  interval = c(meetau, tauUpperSearch),
                                  extendInt = "no",
                                  tol = tol, maxiter = maxiter)$root)
        if (!inherits(upp, "try-error")) {
            out[3] <- upp
        }
    }
    return(out)
}

#' @title Support interval for effect size
#'
#' @description Computes a support interval for the effect size in the
#'     normal-normal hierarchical model based on a set of observed effect
#'     estimates and their standard errors, and prior.
#'
#' @param yi Vector of length n with the observed effect estimates.
#' @param sei Vector of length n with the standard errors of the effect
#'     estimates.
#' @param k Level of the support interval. Defaults to \code{1}.
#' @param tau0 Prior for heterogeneity standard deviation nuisance parameter.
#'     Can be a scalar (a point prior) or a prior density function (a continuous
#'     prior distribution).
#' @param theta1 Prior for effect size under the alternative hypothesis. Can be
#'     a numeric (a point prior) or a prior density function (a continuous prior
#'     distribution).
#' @param tau1 Prior for heterogeneity standard deviation under the alternative
#'     hypothesis. Can be a scalar (a point prior) or a prior density function
#'     (a continuous prior distribution). Defaults to the same prior as
#'     specified for \code{tau0}.
#' @param thetaSEmultSearch The number of \code{max(sei)} around the MEE where
#'     the numerical search for the support limits. Defaults to \code{5}.
#'     Increase or decrease if there are numerical problems computing the
#'     support interval.
#' @param tol Argument passed to \code{stats::uniroot}. Defaults to
#'     \code{.Machine$double.eps^0.25}.
#' @param maxiter Argument passed to \code{stats::uniroot}. Defauls to
#'     \code{1000}.
#' @param thetaLim Integration limits for theta. It is only recommended to
#'     change this argument if a prior distribution truncated to some interval
#'     is specified. Defaults to \code{c(-Inf, Inf)}.
#' @param ... Additional arguments passed to \code{stats::integrate}.
#'
#' @return A k support interval for the effect size
#'
#' @author Samuel Pawel
#'
#' @examples
#' \dontrun{
#' yi <- c(0.5, 0.3, 0.1, 0.4)
#' sei <- c(0.05, 0.06, 0.1, 0.03)
#' ## k = 1 SI for effect size
#' supinttheta(yi = yi, sei = sei, k = 1, tau0 = function(x) dnorm(x = x, sd = 0.5)*2,
#'             theta1 = function(x) dnorm(x = x, sd = 2))
#' }
#' @export
supinttheta <- function(yi, sei, k = 1, tau0, theta1, tau1 = tau0,
                        thetaSEmultSearch = 5, tol = .Machine$double.eps^0.25,
                        maxiter = 1000, thetaLim = c(-Inf, Inf), ...) {

    ## input checks
    stopifnot(is.numeric(k),
              length(k) == 1,
              is.finite(k),
              k > 0,

              is.numeric(tau0) || is.function(tau0)
              )


    ## determine SI for effect size
    meetheta <- mee(yi = yi, sei = sei, tau = tau0, thetaLim = thetaLim, ... = ...)
    kmee <- bf01(yi = yi, sei = sei, theta0 = meetheta, tau0 = tau0,
                 theta1 = theta1, tau1 = tau1, thetaLim = thetaLim, ... = ...)
    out <- c(NaN, meetheta, NaN)
    names(out) <- c(paste0("Lower k=", k), paste0("MEE k=", signif(kmee, 3)),
                    paste0("Upper k=", k))
    if (k < kmee) {
        rootFun. <- function(par) {
            bf01(yi = yi, sei = sei, theta0 = par, tau0 = tau0, theta1 = theta1,
                 tau1 = tau1, thetaLim = thetaLim, ... = ...) - k
        }
        rootFun <- Vectorize(FUN = rootFun.)
        low <- try(stats::uniroot(f = rootFun, interval = c(meetheta - thetaSEmultSearch*max(sei),
                                                            meetheta),
                                  extendInt = "no", tol = tol,
                                  maxiter = maxiter)$root)
        if (!inherits(low, "try-error")) {
            out[1] <- low
        }
        upp <- try(stats::uniroot(f = rootFun,
                                  interval = c(meetheta,
                                               meetheta + thetaSEmultSearch*max(sei)),
                                  extendInt = "no", tol = tol,
                                  maxiter = maxiter)$root)
        if (!inherits(upp, "try-error")) {
            out[3] <- upp
        }
    }

    return(out)
}
